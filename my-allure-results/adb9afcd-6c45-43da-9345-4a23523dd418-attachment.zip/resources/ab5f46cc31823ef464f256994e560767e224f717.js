/**
 * This script lives in the parent window.
 */

window.EmbedManager = window.EmbedManager || new function() {
	var FRAME_NAME_PREFIX = "frame-one";

	var _addListener = function(obj, name, fn) {
		if(obj.addEventListener) {
			obj.addEventListener(name, fn, false);
		} else if(obj.attachEvent) {
			obj.attachEvent("on" + name, fn);
		}
	}

	var _embeds = {};

	_addListener(document, "touchmove", function(evn) {
		// android chrome scrolling fix
	});

	_addListener(window, "message", function(evn) {
		// expect "id:height:scroll"
		if(evn.data && /^\w+:\d+:\w+$/.test(evn.data)) {
			var parts = evn.data.split(':');
			var embed = _embeds[parts[0]];

			if(embed) {
				var frame = document.getElementById(FRAME_NAME_PREFIX + parts[0]);

				if(frame) {
					if (frame.height != parts[1]) {
						frame.height = parts[1];
						embed.callback();
					}

					if(embed.hits++ > 0) {
						if(parts[2] == "true") {
							EmbedManager.scrollPage(parts[0]);
						}
					}
				} else {
					alert("embed frame " + parts[0] + " could not be found");
				}
			}
		}
	});

	return {
		embed: function(params) {
			var embedKey = params.key.replace(/&#038;|&amp;/g, "&"); // fix for CMS (WordPress, etc) double encoding
			var embedId = embedKey.substr(embedKey.indexOf('&') + 1);
			var embedUrl = embedKey + "&EmbedId=" + embedId;
			var embedCallback = params.resizeCallback || function() {};
			var embedTitle = params.title || "";
			var embedWidth = params.width || "100%";

			// assume width is px if no units
			if(embedWidth.indexOf('%') < 0 && embedWidth.indexOf("px") < 0) {
				embedWidth += "px";
			}

			if(params.showFormLogin) {
				if (embedUrl.indexOf("https:") < 0) {
					embedUrl = "https:" + embedUrl.substr(5); // replace http with https
				}

				embedUrl += "&ShowSaveAndReturn=login";
			}
			
			if(params.showSaveAndReturn) {
				if (embedUrl.indexOf("https:") < 0) {
					embedUrl = "https:" + embedUrl.substr(5); // replace http with https
				}

				if(params.showSaveAndReturn == "login") {
					embedUrl += "&ShowSaveAndReturn=login";
				} else if(params.showSaveAndReturn == "signup") {
					embedUrl += "&ShowSaveAndReturn=signup";
				}
			}

			if (params.prePopulate) {
				embedUrl += "&PrePopulate";

				if (params.prePopulate == window.location) {
					// extract pre-populate-looking parameters
					window.location.search.replace(/[?&]+((?:id)?[0-9][0-9-]*)=([^&]*)/g, function(m, p, v) {
						embedUrl += '&' + p + '=' + v;
					});
				} else {
					for (var p in params.prePopulate) {
						var vals = [].concat(params.prePopulate[p]);

						vals.forEach(function(v) {
							embedUrl += '&' + p + '=' + encodeURIComponent(v);
						});
					}
				}
			}

			_embeds[embedId] = { id:embedId, url:embedUrl, callback:embedCallback, hits:0 };

			EmbedManager.createFrame(embedId, embedUrl, embedTitle, embedWidth);
		},

		createFrame: function(embedId, embedUrl, embedTitle, embedWidth) {
			var a = document.getElementById("formAnchor" + embedId);
			var frame = document.createElement("iframe");

			frame.allowTransparency = true;
			frame.frameBorder = 0;
			frame.id = FRAME_NAME_PREFIX + embedId;
			frame.scrolling = "no";
			frame.src = embedUrl;
			frame.style.border = 0;
			frame.style.margin = 0;
			frame.style.padding = 0;
			frame.style.width = embedWidth;
			frame.title = embedTitle;

			a.parentNode.insertBefore(frame, a);
		},

		scrollPage: function(embedId) {
			function findPos(el) {
				var left = 0;
				var top = 0;

				if (el.offsetParent) {
					do {
						left += el.offsetLeft;
						top += el.offsetTop;
					} while (el = el.offsetParent);

					return { X:left, Y:top };
				}
			}

			var frame = document.getElementById(FRAME_NAME_PREFIX + embedId);
			var framePos = findPos(frame);

			if(framePos) {
				var scrollY = window.pageYOffset || document.documentElement.scrollTop

				if(scrollY > framePos.Y) {
					// scroll top of form into view
					window.scrollTo(framePos.X, framePos.Y);
				}
			}
		}
	};
}();
